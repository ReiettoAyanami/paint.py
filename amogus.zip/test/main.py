from asyncio import events
import json
import os
import pygame
from pygame.constants import MOUSEBUTTONDOWN
from pygame.time import Clock
from src.lzbrush_conversion import lzbrushfile_to_pygame_surface
from inventory_menu import Inventory_Menu
from src.brush import Brush
from image_button import Image_Button
from string_button import String_Button
pygame.init()
pygame.font.init()
SIZE = WIDTH, HEIGHT = (600,400)
BGCOLOR = (50,50,50)
GFONT = pygame.font.SysFont("Comic Sans MS", 30)
window = pygame.display.set_mode(SIZE,pygame.RESIZABLE)
pygame.display.set_caption('test')
clock = Clock()

susButton = String_Button((100,100,100,20), 'amogus', pygame.font.SysFont('Arial', 10))
bgimg = pygame.image.load('yelenadstare.png')
pygame.transform.scale(bgimg, SIZE)

bs = []


for i, f in enumerate(os.listdir('newlzb')):
    
    sus = lzbrushfile_to_pygame_surface(f'newlzb/{f}')
    sus.fill((255,255,255), special_flags=pygame.BLEND_ADD)

    bs.append(sus)


im = Inventory_Menu(bs,row_length=5, button_dimension=20, color=(100,100,100, 100), outline_color=(0,0,0,0), hovering_color=(255,0,0,100))

def main():
    
    running = True

    mouse_pressed = {
                        'left' : False, 
                        'right':False, 
                        'wheel': False
                    }
    selected_brush = 0
    
    while running:
        clock.tick(60)
        
        mouse_clicked = {   
                            'left' : False, 
                            'right':False, 
                            'wheel': False
                        }
        mouse_moved = False
        mouse_scroll = 0

        events = {
            'mouse_clicked': mouse_clicked,
            'mouse_pressed': mouse_pressed
        }
        
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEMOTION:
                mouse_moved = True
            

            if event.type == MOUSEBUTTONDOWN:
                if event.button == pygame.BUTTON_LEFT:
                    mouse_pressed['left'] = True
                    mouse_clicked['left'] = True

                elif event.button == pygame.BUTTON_MIDDLE:
                    mouse_pressed['wheel'] = True
                    mouse_clicked['wheel'] = True

                elif event.button == pygame.BUTTON_RIGHT:
                    mouse_pressed['right'] = True
                    mouse_clicked['right'] = True

            if event.type == pygame.MOUSEBUTTONUP:
                if event.button == pygame.BUTTON_LEFT:
                    mouse_pressed['left'] = False
                elif event.button == pygame.BUTTON_MIDDLE:
                    mouse_pressed['wheel'] = False
                elif event.button == pygame.BUTTON_RIGHT:
                    mouse_pressed['right'] = False

        window.fill(BGCOLOR)
        window.blit(bgimg, (0,0))
        
        
        im.show(window)
        im.update(events)
        print(im.get_selected())

        pygame.display.update()

if __name__ == '__main__':
    main()