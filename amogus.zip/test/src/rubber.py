import pygame



class Rubber:

    def __init__(self, dimension:int) -> None:
        
        self.dimension = dimension


    def paint(self, dest_surf:pygame.surface):

        for i in range(self.dimension):
            for j in range(self.dimension):

                dest_surf.set_at((pygame.mouse.get_pos()[0] + i, pygame.mouse.get_pos()[1] + j),(0,0,0,0))