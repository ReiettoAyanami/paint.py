import pygame
class Canvas:

    def __init__(self, window:pygame.Surface) -> None:
        
        self.surface = pygame.Surface(window.get_size(), pygame.SRCALPHA, 32)
        self.surface.convert_alpha()
        

    
